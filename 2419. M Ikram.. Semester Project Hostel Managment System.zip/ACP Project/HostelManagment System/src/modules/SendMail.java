/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modules;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {



    public static void smail(String _password,String recepient,String _roomNo)  throws Exception{
        // Recipient's email ID needs to be mentioned.

        // Sender's email ID needs to be mentioned
        // Assuming you are sending email from through gmails smtp
        // Get system properties
        Properties properties = new Properties();

        // Setup mail server
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.ssl.trust", "*");

        String myAccountEmail="2419@students.riphah.edu.pk";
        String password = "Ikram@123";

        Session session;
        session = Session.getInstance(properties, new Authenticator() {
            //@Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myAccountEmail, password);

            }

        });
        Message message = prepareMessage(session,myAccountEmail,recepient,_password, _roomNo);
        Transport.send(message);
            System.out.println("Sent message successfully....");

        // Used to debug SMTP issues
        session.setDebug(true);
    }
        private static Message prepareMessage(Session session,String myAccountEmail,String recepient,String _password ,String _roomNo){

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(myAccountEmail));

            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recepient));

            // Set Subject: header field
            message.setSubject("Thanks For Joining Our Hostel");

            // Now set the actual message
            message.setText("Hi Thanks For Joining Our Hostel. Your Room No is "+ _roomNo);

            System.out.println("sending...");
            // Send message
            return message;
        } catch (Exception ex) {
             System.out.println(ex);
            Logger.getLogger(SendMail.class.getName()).log(Level.SEVERE,null,ex);
        }
        return null;

    }
        public static String Recipient(String s)
        {
            System.out.println(s);
            return s;
        }

    public static void main(String[] args) throws Exception
    {


    }
}
