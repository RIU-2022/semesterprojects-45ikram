/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hostelmanagment;

/**
 *
 * @author ikram
 */

public class HostelManagment {

    /**
     * @param args the command line arguments
     */
    ////////create functions in class and call them on events
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
